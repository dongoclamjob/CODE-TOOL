﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Threading;
using System.Net.Http;
using System.Text.RegularExpressions;

// MailKit + MimeKit
using MailKit.Net.Imap;
using MailKit.Security;
using MailKit;
using MimeKit;

namespace HotmailOAuth2Reader
{
    public partial class Form1 : Form
    {
        // Lưu danh sách mail đọc được => "View email"
        private List<MailItem> mailItems = new List<MailItem>();

        // Đếm STT cho bảng tài khoản
        private int accountCounter = 0;
        // Đếm STT cho bảng kết quả
        private int sttCounter = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Thiết lập cột cho dataGridViewAccounts (bảng trên)
            dataGridViewAccounts.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewAccounts.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewAccounts.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewAccounts.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);

            // 6 cột: STT, Email, Pass, RefreshToken, ClientId, Status
            dataGridViewAccounts.Columns.Add("STT", "STT");
            dataGridViewAccounts.Columns.Add("Email", "Email");
            dataGridViewAccounts.Columns.Add("Pass", "Pass");
            dataGridViewAccounts.Columns.Add("RefreshToken", "RefreshToken");
            dataGridViewAccounts.Columns.Add("ClientId", "ClientId");
            dataGridViewAccounts.Columns.Add("Status", "Status");

            // Tạo cột cho dataGridViewResults (bảng dưới)
            dataGridViewResults.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewResults.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewResults.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewResults.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);

            dataGridViewResults.Columns.Add("STT", "STT");
            dataGridViewResults.Columns.Add("Email", "Email");
            dataGridViewResults.Columns.Add("Subject", "Subject");
            dataGridViewResults.Columns.Add("Date", "Date");
            dataGridViewResults.Columns.Add("Preview", "Preview");

            // Cột Action => View email
            DataGridViewButtonColumn colAction = new DataGridViewButtonColumn();
            colAction.Name = "Action";
            colAction.HeaderText = "Action";
            colAction.Text = "View email";
            colAction.UseColumnTextForButtonValue = true;
            dataGridViewResults.Columns.Add(colAction);
        }

        // ==================== MENU EVENT HANDLERS ====================

        /// <summary>
        /// 1) Paste (không xóa dữ liệu cũ)
        /// => Thêm vào dataGridViewAccounts nếu đúng định dạng,
        ///    nếu sai thì không thêm. Sau khi duyệt => hiện MessageBox
        /// </summary>
        private void menuPasteNoClear_Click(object sender, EventArgs e)
        {
            if (!Clipboard.ContainsText()) return;

            string text = Clipboard.GetText();
            if (string.IsNullOrWhiteSpace(text)) return;

            // Tách từng dòng
            string[] lines = text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);

            int validCount = 0;
            int invalidCount = 0;

            foreach (var line in lines)
            {
                var parts = line.Split('|');
                if (parts.Length == 4)
                {
                    // Tăng STT
                    int rowNumber = Interlocked.Increment(ref accountCounter);
                    // Thêm vào dataGridViewAccounts
                    dataGridViewAccounts.Rows.Add(rowNumber, parts[0], parts[1], parts[2], parts[3], "");
                    validCount++;
                }
                else
                {
                    invalidCount++;
                }
            }

            // Sau khi duyệt
            if (invalidCount == 0 && validCount > 0)
            {
                MessageBox.Show($"OK...({validCount}) account!", "Paste Result",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                int total = validCount + invalidCount;
                MessageBox.Show($"FAIL...({total}) email|pass|refresh_token|client_id", "Paste Result",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        /// 2) Paste (xóa hết dữ liệu cũ trước)
        /// => Clear grid, paste như PasteNoClear
        /// </summary>
        private void menuPasteClear_Click(object sender, EventArgs e)
        {
            if (!Clipboard.ContainsText()) return;

            string text = Clipboard.GetText();
            if (string.IsNullOrWhiteSpace(text)) return;

            // Xóa dữ liệu cũ
            dataGridViewAccounts.Rows.Clear();
            accountCounter = 0;

            // Tách dòng
            string[] lines = text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);

            int validCount = 0;
            int invalidCount = 0;

            foreach (var line in lines)
            {
                var parts = line.Split('|');
                if (parts.Length == 4)
                {
                    int rowNumber = Interlocked.Increment(ref accountCounter);
                    dataGridViewAccounts.Rows.Add(rowNumber, parts[0], parts[1], parts[2], parts[3], "");
                    validCount++;
                }
                else
                {
                    invalidCount++;
                }
            }

            if (invalidCount == 0 && validCount > 0)
            {
                MessageBox.Show($"OK...({validCount}) account!", "Paste Result",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                int total = validCount + invalidCount;
                MessageBox.Show($"FAIL...({total}) email|pass|refresh_token|client_id", "Paste Result",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        /// <summary>
        /// 3) Chọn tất cả
        /// </summary>
        private void menuSelectAll_Click(object sender, EventArgs e)
        {
            dataGridViewAccounts.SelectAll();
        }

        /// <summary>
        /// 4) Chọn dòng bôi đen (theo vị trí chuột)
        /// </summary>
        private void menuSelectRowUnderMouse_Click(object sender, EventArgs e)
        {
            var mousePos = dataGridViewAccounts.PointToClient(Cursor.Position);
            var hit = dataGridViewAccounts.HitTest(mousePos.X, mousePos.Y);
            if (hit.RowIndex >= 0)
            {
                dataGridViewAccounts.ClearSelection();
                dataGridViewAccounts.Rows[hit.RowIndex].Selected = true;
            }
        }

        /// <summary>
        /// 5) Xóa tất cả
        /// </summary>
        private void menuDeleteAll_Click(object sender, EventArgs e)
        {
            dataGridViewAccounts.Rows.Clear();
            accountCounter = 0;
        }

        /// <summary>
        /// 6) Xóa dòng bôi đen
        /// </summary>
        private void menuDeleteSelected_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridViewAccounts.SelectedRows)
            {
                if (!row.IsNewRow)
                    dataGridViewAccounts.Rows.Remove(row);
            }
        }

        /// <summary>
        /// 7) Copy (các dòng được chọn) - format email|pass|refresh_token|client_id
        /// </summary>
        private void menuCopySelected_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            foreach (DataGridViewRow row in dataGridViewAccounts.SelectedRows)
            {
                string email = row.Cells["Email"].Value?.ToString() ?? "";
                string pass = row.Cells["Pass"].Value?.ToString() ?? "";
                string refresh = row.Cells["RefreshToken"].Value?.ToString() ?? "";
                string clientId = row.Cells["ClientId"].Value?.ToString() ?? "";

                sb.AppendLine($"{email}|{pass}|{refresh}|{clientId}");
            }
            if (sb.Length > 0)
            {
                Clipboard.SetText(sb.ToString().TrimEnd());
            }
        }

        // =========== NÚT READ HOTMAIL =============
        private async void buttonReadHotmail_Click(object sender, EventArgs e)
        {
            // Clear kết quả cũ
            dataGridViewResults.Rows.Clear();
            mailItems.Clear();

            // Đặt STT cho bảng kết quả bắt đầu từ 0 => email đầu sẽ hiển thị 1
            sttCounter = 0;

            // Lấy danh sách tài khoản
            List<AccountInfo> accounts = new List<AccountInfo>();
            foreach (DataGridViewRow row in dataGridViewAccounts.Rows)
            {
                if (row.IsNewRow) continue;

                int sttValue = row.Cells["STT"].Value == null ? 0 : Convert.ToInt32(row.Cells["STT"].Value);
                string email = row.Cells["Email"].Value?.ToString() ?? "";
                string pass = row.Cells["Pass"].Value?.ToString() ?? "";
                string refresh = row.Cells["RefreshToken"].Value?.ToString() ?? "";
                string clientId = row.Cells["ClientId"].Value?.ToString() ?? "";

                if (string.IsNullOrEmpty(refresh)) continue;

                accounts.Add(new AccountInfo
                {
                    STT = sttValue,
                    Email = email,
                    Pass = pass,
                    RefreshToken = refresh,
                    ClientId = clientId
                });
            }

            // Đa luồng => tránh lag
            List<Task> tasks = new List<Task>();
            foreach (var acc in accounts)
            {
                tasks.Add(Task.Run(async () => { await ProcessAccount(acc); }));
            }
            await Task.WhenAll(tasks);
        }

        // Hàm xử lý từng tài khoản
        private async Task ProcessAccount(AccountInfo acc)
        {
            string? accessToken = await RefreshAccessTokenAsync(acc.RefreshToken, acc.ClientId);
            if (string.IsNullOrEmpty(accessToken))
            {
                // Gọi UpdateAccountStatus nếu cần
                UpdateAccountStatus(acc.STT, "FAIL");

                // Thêm dòng fail vào bảng kết quả
                AddRowToResults(new object?[]
                {
                    Interlocked.Increment(ref sttCounter),
                    acc.Email,
                    "Failed to get access token",
                    "",
                    "",
                    ""
                });
                return;
            }

            try
            {
                using var imap = new ImapClient();
                imap.Connect("outlook.office365.com", 993, SecureSocketOptions.SslOnConnect);

                var oauth2 = new SaslMechanismOAuth2(acc.Email ?? "", accessToken);
                imap.Authenticate(oauth2);

                UpdateAccountStatus(acc.STT, "OK");

                var inbox = imap.Inbox;
                inbox.Open(FolderAccess.ReadOnly);

                int count = inbox.Count;
                int startIndex = Math.Max(count - 5, 0);

                for (int i = startIndex; i < count; i++)
                {
                    var message = inbox.GetMessage(i);

                    string subject = message.Subject ?? "";
                    string date = message.Date.ToString("dd/MM/yyyy HH:mm");
                    string textBody = message.TextBody ?? "";
                    string preview = textBody.Length > 100
                        ? textBody.Substring(0, 100) + "..."
                        : textBody;

                    string fullBody = !string.IsNullOrEmpty(message.HtmlBody)
                        ? message.HtmlBody
                        : textBody;

                    int currentStt = Interlocked.Increment(ref sttCounter);

                    lock (mailItems)
                    {
                        mailItems.Add(new MailItem
                        {
                            STT = currentStt,
                            Email = acc.Email,
                            Subject = subject,
                            Date = date,
                            Preview = preview,
                            FullContent = fullBody
                        });
                    }

                    AddRowToResults(new object?[]
                    {
                        currentStt,
                        acc.Email,
                        subject,
                        date,
                        preview,
                        "View email"
                    });
                }

                imap.Disconnect(true);
            }
            catch (Exception ex)
            {
                UpdateAccountStatus(acc.STT, "FAIL");

                AddRowToResults(new object?[]
                {
                    Interlocked.Increment(ref sttCounter),
                    acc.Email,
                    $"Error: {ex.Message}",
                    "",
                    "",
                    ""
                });
            }
        }

        // Gọi OAuth2.0 => đổi refresh_token -> access_token
        private async Task<string?> RefreshAccessTokenAsync(string refreshToken, string clientId)
        {
            try
            {
                using var client = new HttpClient();
                var dict = new Dictionary<string, string>()
                {
                    { "grant_type", "refresh_token" },
                    { "refresh_token", refreshToken },
                    { "client_id", clientId },
                    { "scope", "offline_access https://outlook.office.com/IMAP.AccessAsUser.All" }
                };
                var content = new FormUrlEncodedContent(dict);
                var response = await client.PostAsync(
                    "https://login.microsoftonline.com/common/oauth2/v2.0/token",
                    content
                );
                var json = await response.Content.ReadAsStringAsync();

                var match = Regex.Match(json, "\"access_token\":\"(.*?)\"");
                if (match.Success)
                {
                    return match.Groups[1].Value.Replace("\\u002f", "/");
                }
            }
            catch
            {
                // ignore
            }
            return null;
        }

        // Cập nhật Status ở bảng tài khoản (nếu cần)
        private void UpdateAccountStatus(int stt, string status)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => UpdateAccountStatus(stt, status)));
                return;
            }
            // Tìm row có STT == stt
            foreach (DataGridViewRow row in dataGridViewAccounts.Rows)
            {
                if (row.IsNewRow) continue;
                int rowStt = row.Cells["STT"].Value == null ? 0 : Convert.ToInt32(row.Cells["STT"].Value);
                if (rowStt == stt)
                {
                    row.Cells["Status"].Value = status;
                    break;
                }
            }
        }

        // Thêm row vào dataGridViewResults (thread-safe)
        private void AddRowToResults(object?[] rowValues)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => dataGridViewResults.Rows.Add(rowValues)));
            }
            else
            {
                dataGridViewResults.Rows.Add(rowValues);
            }
        }

        // Khi bấm "View email" ở bảng kết quả
        private void dataGridViewResults_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            if (dataGridViewResults.Columns[e.ColumnIndex].Name == "Action")
            {
                var row = dataGridViewResults.Rows[e.RowIndex];
                if (row.Cells["STT"].Value == null) return;

                int sttValue = Convert.ToInt32(row.Cells["STT"].Value);

                MailItem? mail = null;
                lock (mailItems)
                {
                    mail = mailItems.Find(x => x.STT == sttValue);
                }
                if (mail != null)
                {
                    FormViewEmail frm = new FormViewEmail(mail);
                    frm.ShowDialog();
                }
            }
        }
    }

    // Lớp lưu 1 tài khoản
    public class AccountInfo
    {
        public int STT { get; set; }       // STT cho tài khoản
        public string? Email { get; set; }
        public string? Pass { get; set; }
        public string? RefreshToken { get; set; }
        public string? ClientId { get; set; }
    }

    // Lớp lưu thông tin 1 email
    public class MailItem
    {
        public int STT { get; set; }
        public string? Email { get; set; }
        public string? Subject { get; set; }
        public string? Date { get; set; }
        public string? Preview { get; set; }
        public string? FullContent { get; set; }
    }
}
