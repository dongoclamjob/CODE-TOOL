﻿using System.Windows.Forms;

namespace HotmailOAuth2Reader
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private DataGridView dataGridViewAccounts;   // Bảng trên: Tài khoản
        private DataGridView dataGridViewResults;    // Bảng dưới: Kết quả
        private Button buttonReadHotmail;

        // ContextMenu cho dataGridViewAccounts
        private ContextMenuStrip contextMenuAccounts;
        private ToolStripMenuItem menuPasteNoClear;
        private ToolStripMenuItem menuPasteClear;
        private ToolStripMenuItem menuSelectAll;
        private ToolStripMenuItem menuSelectRowUnderMouse;
        private ToolStripMenuItem menuDeleteAll;
        private ToolStripMenuItem menuDeleteSelected;
        private ToolStripMenuItem menuCopySelected;

        // Label thương hiệu
        private Label labelBrand;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridViewAccounts = new System.Windows.Forms.DataGridView();
            this.dataGridViewResults = new System.Windows.Forms.DataGridView();
            this.buttonReadHotmail = new System.Windows.Forms.Button();

            this.contextMenuAccounts = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuPasteNoClear = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPasteClear = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSelectRowUnderMouse = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDeleteAll = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDeleteSelected = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCopySelected = new System.Windows.Forms.ToolStripMenuItem();

            this.labelBrand = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAccounts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResults)).BeginInit();
            this.contextMenuAccounts.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewAccounts
            // 
            this.dataGridViewAccounts.AllowUserToAddRows = true;
            this.dataGridViewAccounts.AllowUserToDeleteRows = true;
            this.dataGridViewAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewAccounts.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewAccounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAccounts.ContextMenuStrip = this.contextMenuAccounts;
            this.dataGridViewAccounts.Location = new System.Drawing.Point(12, 12);
            this.dataGridViewAccounts.MultiSelect = true;
            this.dataGridViewAccounts.Name = "dataGridViewAccounts";
            this.dataGridViewAccounts.RowHeadersVisible = false;
            this.dataGridViewAccounts.RowTemplate.Height = 28;
            this.dataGridViewAccounts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAccounts.Size = new System.Drawing.Size(850, 200);
            this.dataGridViewAccounts.TabIndex = 0;
            // 
            // dataGridViewResults
            // 
            this.dataGridViewResults.AllowUserToAddRows = false;
            this.dataGridViewResults.AllowUserToDeleteRows = false;
            this.dataGridViewResults.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewResults.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridViewResults.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewResults.Location = new System.Drawing.Point(12, 270);
            this.dataGridViewResults.MultiSelect = false;
            this.dataGridViewResults.Name = "dataGridViewResults";
            this.dataGridViewResults.RowHeadersVisible = false;
            this.dataGridViewResults.RowTemplate.Height = 28;
            this.dataGridViewResults.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewResults.Size = new System.Drawing.Size(850, 220);
            this.dataGridViewResults.TabIndex = 1;
            this.dataGridViewResults.CellClick += new DataGridViewCellEventHandler(this.dataGridViewResults_CellClick);
            // 
            // buttonReadHotmail
            // 
            this.buttonReadHotmail.BackColor = System.Drawing.Color.LightSteelBlue;
            this.buttonReadHotmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonReadHotmail.Location = new System.Drawing.Point(12, 218);
            this.buttonReadHotmail.Name = "buttonReadHotmail";
            this.buttonReadHotmail.Size = new System.Drawing.Size(140, 40);
            this.buttonReadHotmail.TabIndex = 2;
            this.buttonReadHotmail.Text = "Read Hotmail";
            this.buttonReadHotmail.UseVisualStyleBackColor = false;
            this.buttonReadHotmail.Click += new System.EventHandler(this.buttonReadHotmail_Click);
            // 
            // contextMenuAccounts
            // 
            this.contextMenuAccounts.Items.AddRange(new ToolStripItem[] {
                this.menuPasteNoClear,
                this.menuPasteClear,
                this.menuSelectAll,
                this.menuSelectRowUnderMouse,
                this.menuDeleteAll,
                this.menuDeleteSelected,
                this.menuCopySelected
            });
            this.contextMenuAccounts.Name = "contextMenuAccounts";
            this.contextMenuAccounts.Size = new System.Drawing.Size(300, 158);
            // 
            // menuPasteNoClear
            // 
            this.menuPasteNoClear.Name = "menuPasteNoClear";
            this.menuPasteNoClear.Size = new System.Drawing.Size(299, 22);
            this.menuPasteNoClear.Text = "Paste (no delete)";
            this.menuPasteNoClear.Click += new System.EventHandler(this.menuPasteNoClear_Click);
            // 
            // menuPasteClear
            // 
            this.menuPasteClear.Name = "menuPasteClear";
            this.menuPasteClear.Size = new System.Drawing.Size(299, 22);
            this.menuPasteClear.Text = "Paste (delete all)";
            this.menuPasteClear.Click += new System.EventHandler(this.menuPasteClear_Click);
            // 
            // menuSelectAll
            // 
            this.menuSelectAll.Name = "menuSelectAll";
            this.menuSelectAll.Size = new System.Drawing.Size(299, 22);
            this.menuSelectAll.Text = "Click all";
            this.menuSelectAll.Click += new System.EventHandler(this.menuSelectAll_Click);
            // 
            // menuSelectRowUnderMouse
            // 
            this.menuSelectRowUnderMouse.Name = "menuSelectRowUnderMouse";
            this.menuSelectRowUnderMouse.Size = new System.Drawing.Size(299, 22);
            this.menuSelectRowUnderMouse.Text = "Click";
            this.menuSelectRowUnderMouse.Click += new System.EventHandler(this.menuSelectRowUnderMouse_Click);
            // 
            // menuDeleteAll
            // 
            this.menuDeleteAll.Name = "menuDeleteAll";
            this.menuDeleteAll.Size = new System.Drawing.Size(299, 22);
            this.menuDeleteAll.Text = "Delete all";
            this.menuDeleteAll.Click += new System.EventHandler(this.menuDeleteAll_Click);
            // 
            // menuDeleteSelected
            // 
            this.menuDeleteSelected.Name = "menuDeleteSelected";
            this.menuDeleteSelected.Size = new System.Drawing.Size(299, 22);
            this.menuDeleteSelected.Text = "Delete";
            this.menuDeleteSelected.Click += new System.EventHandler(this.menuDeleteSelected_Click);
            // 
            // menuCopySelected
            // 
            this.menuCopySelected.Name = "menuCopySelected";
            this.menuCopySelected.Size = new System.Drawing.Size(299, 22);
            this.menuCopySelected.Text = "Copy all";
            this.menuCopySelected.Click += new System.EventHandler(this.menuCopySelected_Click);
            // 
            // labelBrand
            // 
            this.labelBrand.AutoSize = true;
            this.labelBrand.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic);
            this.labelBrand.ForeColor = System.Drawing.Color.Gray;
            this.labelBrand.Location = new System.Drawing.Point(720, 495);
            this.labelBrand.Name = "labelBrand";
            this.labelBrand.Size = new System.Drawing.Size(142, 18);
            this.labelBrand.TabIndex = 3;
            this.labelBrand.Text = "© Metafast - 2025    ";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(874, 522);
            this.Controls.Add(this.labelBrand);
            this.Controls.Add(this.buttonReadHotmail);
            this.Controls.Add(this.dataGridViewResults);
            this.Controls.Add(this.dataGridViewAccounts);
            this.Name = "Form1";
            this.Text = "Tool Read Hotmail - @Metafast 1.1";
            this.Load += new System.EventHandler(this.Form1_Load);

            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAccounts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewResults)).EndInit();
            this.contextMenuAccounts.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
