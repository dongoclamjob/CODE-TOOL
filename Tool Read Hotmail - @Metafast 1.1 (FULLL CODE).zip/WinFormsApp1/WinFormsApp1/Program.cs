using HotmailOAuth2Reader;
using System;
using System.Windows.Forms;

namespace ToolFacebook
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());  // Ch?y Form1 thay v� MainForm
        }
    }
}
