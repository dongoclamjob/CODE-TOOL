﻿using System;
using System.Windows.Forms;

namespace HotmailOAuth2Reader
{
    public partial class FormViewEmail : Form
    {
        private MailItem mail;

        public FormViewEmail(MailItem item)
        {
            InitializeComponent();
            mail = item;
        }

        private void FormViewEmail_Load(object sender, EventArgs e)
        {
            labelSubject.Text = "Subject: " + mail.Subject;
            labelDate.Text = "Date: " + mail.Date;
            labelEmail.Text = "Email: " + mail.Email;

            // Hiển thị nội dung HTML (hoặc text) trong webBrowser
            webBrowser1.DocumentText = mail.FullContent ?? "";
        }
    }
}
